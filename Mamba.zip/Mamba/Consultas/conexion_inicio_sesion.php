<?php
   $cn = new mysqli("localhost", "root", "mysql123","MAMBA_USUARIO"); 

